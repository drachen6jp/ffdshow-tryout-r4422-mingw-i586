#include <mmdeviceapi.h>
